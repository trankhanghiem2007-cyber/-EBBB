import { useState, useEffect, useRef, useCallback } from 'react';
import axios from 'axios';

export const useSniperLogic = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [targetTime, setTargetTime] = useState(null);
  const [timeOffset, setTimeOffset] = useState(0);
  const [isArmed, setIsArmed] = useState(false);
  const [status, setStatus] = useState('IDLE'); // IDLE, ARMED, FIRING, SUCCESS, FAILED
  const [logs, setLogs] = useState([]);
  
  const timerRef = useRef(null);
  const fireIntervalRef = useRef(null);

  const addLog = useCallback((message, type = 'info') => {
    const timestamp = new Date().toISOString().substring(11, 23); // Lấy HH:mm:ss.SSS
    setLogs((prev) => [...prev, { id: Date.now() + Math.random(), time: timestamp, message, type }]);
  }, []);

  // 1. Hàm mô phỏng đồng bộ thời gian với NTP Server
  const syncTime = async () => {
    addLog('Đang đồng bộ thời gian với NTP Server...', 'warning');
    try {
      // Mô phỏng call API lấy thời gian server
      const start = performance.now();
      // await axios.get('https://worldtimeapi.org/api/timezone/Etc/UTC');
      await new Promise(resolve => setTimeout(resolve, 300)); // Fake latency
      const end = performance.now();
      const latency = Math.round(end - start);
      
      // Giả sử offset = 0 cho môi trường local
      setTimeOffset(0); 
      addLog(`[NTP Sync] Thành công! Độ trễ: ${latency}ms`, 'success');
    } catch (error) {
      addLog(`[NTP Error] Lỗi đồng bộ: ${error.message}`, 'error');
    }
  };

  // 2. Logic tính toán Target Time (00:00:00 ngày tiếp theo)
  useEffect(() => {
    const setupTarget = () => {
      const target = new Date();
      target.setHours(0, 0, 0, 0); // Mặc định là 0h
      // Nếu giờ hiện tại đã qua 0h, set target cho ngày mai
      if (target.getTime() <= Date.now()) {
        target.setDate(target.getDate() + 1);
      }
      // Dành cho test: Chỉnh target time cách hiện tại 15 giây nếu muốn test ngay
      // target.setTime(Date.now() + 15000); 
      setTargetTime(target);
    };
    setupTarget();
    syncTime();
  }, [addLog]);

  // 3. Vòng lặp đếm ngược cực nhanh (10ms) để UI mượt mà
  useEffect(() => {
    if (!targetTime) return;

    timerRef.current = setInterval(() => {
      const now = new Date(Date.now() + timeOffset);
      setCurrentTime(now);

      const diff = targetTime.getTime() - now.getTime();

      // Trigger khoảnh khắc Vàng (00:00:00.000)
      if (isArmed && diff <= 0 && status !== 'FIRING' && status !== 'SUCCESS') {
        startFiringLogic();
      }
    }, 10);

    return () => clearInterval(timerRef.current);
  }, [targetTime, timeOffset, isArmed, status]);

  // 4. Logic bắn request cường độ cao
  const startFiringLogic = () => {
    setStatus('FIRING');
    addLog('>>> TARGET REACHED. COMMENCING FIRE LOOP... <<<', 'warning');
    
    let attempt = 0;
    const maxAttempts = 50; // Bắn liên tục 50 request (hoặc chạy trong 5 phút)
    
    // Sử dụng setInterval tốc độ cao (hoặc Promise.all)
    fireIntervalRef.current = setInterval(async () => {
      attempt++;
      addLog(`[Request #${attempt}] Đang nạp payload...`, 'info');
      
      try {
        // MÔ PHỎNG GỌI API SHOPEE
        // const res = await axios.post('https://shopee.vn/api/v2/voucher/claim', { voucher_id: 'XYZ' }, { headers: { Cookie: '...' }});
        await new Promise(r => setTimeout(r, Math.random() * 50 + 20)); // Fake API delay 20-70ms
        
        // Giả lập tỷ lệ thành công ngẫu nhiên ở request thứ 15
        if (attempt === 15) {
          clearInterval(fireIntervalRef.current);
          setStatus('SUCCESS');
          addLog(`[Request #${attempt}] MÃ ĐÃ ĐƯỢC LẤY THÀNH CÔNG! (Status 200)`, 'success');
          setIsArmed(false);
        } else {
          addLog(`[Request #${attempt}] Thất bại: Mã chưa có hiệu lực hoặc hết lượt.`, 'error');
        }

      } catch (err) {
        addLog(`[Request #${attempt}] Lỗi mạng: ${err.message}`, 'error');
      }

      if (attempt >= maxAttempts && status !== 'SUCCESS') {
        clearInterval(fireIntervalRef.current);
        setStatus('FAILED');
        addLog('Đã hết 5 phút hoặc max lượt thử. Hủy chiến dịch.', 'error');
        setIsArmed(false);
      }
    }, 100); // Tốc độ bắn: 100ms/request (Có thể chỉnh thấp hơn tùy Rate Limit)
  };

  const toggleArm = () => {
    if (!isArmed) {
      setIsArmed(true);
      setStatus('ARMED');
      addLog('HỆ THỐNG ĐÃ SẴN SÀNG (ARMED). Chờ lệnh khai hỏa...', 'warning');
    } else {
      setIsArmed(false);
      setStatus('IDLE');
      addLog('Đã hủy trạng thái sẵn sàng.', 'info');
    }
  };

  return { currentTime, targetTime, isArmed, status, logs, toggleArm };
};
