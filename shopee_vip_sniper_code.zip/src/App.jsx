import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Zap, ShieldCheck, Terminal, Crosshair } from 'lucide-react';
import { useSniperLogic } from './hooks/useSniperLogic';

const App = () => {
  const { currentTime, targetTime, isArmed, status, logs, toggleArm } = useSniperLogic();
  const logEndRef = useRef(null);

  // Auto-scroll Terminal
  useEffect(() => {
    if (logEndRef.current) {
      logEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs]);

  // Hàm format thời gian đếm ngược
  const formatCountdown = () => {
    if (!targetTime) return { h: '00', m: '00', s: '00', ms: '000' };
    const diff = targetTime.getTime() - currentTime.getTime();
    if (diff <= 0) return { h: '00', m: '00', s: '00', ms: '000' };

    const h = Math.floor((diff / (1000 * 60 * 60)) % 24).toString().padStart(2, '0');
    const m = Math.floor((diff / 1000 / 60) % 60).toString().padStart(2, '0');
    const s = Math.floor((diff / 1000) % 60).toString().padStart(2, '0');
    const ms = Math.floor(diff % 1000).toString().padStart(3, '0');
    return { h, m, s, ms, rawDiff: diff };
  };

  const cd = formatCountdown();
  const isDangerZone = cd.rawDiff && cd.rawDiff <= 10000; // Dưới 10 giây

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 lg:p-8 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-neutral-900 via-[#0a0a0a] to-[#0a0a0a]">
      
      {/* HEADER */}
      <motion.header 
        initial={{ y: -50, opacity: 0 }} 
        animate={{ y: 0, opacity: 1 }}
        className="w-full max-w-4xl flex items-center justify-between mb-8"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 bg-[#ee4d2d]/20 rounded-xl border border-[#ee4d2d]/50 glow-box">
            <Zap className="text-[#ee4d2d]" size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-wider text-white">SHOPEE <span className="text-[#ee4d2d] glow-text-orange">VIP SNIPER</span></h1>
            <p className="text-xs text-neutral-400 tracking-widest font-mono">v3.0.0 // LOW-LATENCY EDITION</p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-sm font-mono bg-neutral-900/50 px-4 py-2 rounded-full border border-neutral-800">
          <div className={`w-2 h-2 rounded-full ${status === 'SUCCESS' ? 'bg-green-500' : 'bg-[#ee4d2d] animate-pulse'}`}></div>
          <span className="text-neutral-300">Server: <span className="text-white">v3-API-HCM</span></span>
        </div>
      </motion.header>

      {/* MAIN CONTENT GRID */}
      <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-12 gap-6 relative z-10">
        
        {/* LEFT COL: COUNTDOWN & CONTROLS */}
        <div className="md:col-span-7 flex flex-col gap-6">
          
          {/* TIMER CARD */}
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
            className={`p-8 rounded-3xl bg-neutral-900/40 border backdrop-blur-md flex flex-col items-center justify-center
              ${isDangerZone ? 'border-red-500/50 animate-pulse-danger shadow-[0_0_30px_rgba(239,68,68,0.2)]' : 'border-[#ee4d2d]/30 shadow-[0_0_30px_rgba(238,77,45,0.05)]'}
            `}
          >
            <h2 className="text-sm uppercase tracking-[0.3em] text-neutral-400 mb-4 font-semibold">T-Minus to Execution</h2>
            <div className={`font-mono text-5xl sm:text-7xl font-black flex items-baseline gap-2 
              ${isDangerZone ? 'text-red-500 glow-text-red' : 'text-white'}`}>
              <span>{cd.h}</span><span className="text-neutral-600">:</span>
              <span>{cd.m}</span><span className="text-neutral-600">:</span>
              <span>{cd.s}</span>
              <span className={`text-2xl sm:text-4xl ${isDangerZone ? 'text-red-400' : 'text-[#ee4d2d]'}`}>.{cd.ms}</span>
            </div>
            
            <div className="mt-6 flex gap-4 text-xs font-mono text-neutral-500">
              <span className="flex items-center gap-1"><ShieldCheck size={14}/> NTP Synced</span>
              <span className="flex items-center gap-1"><Crosshair size={14}/> Auto-Fire: ON</span>
            </div>
          </motion.div>

          {/* CONTROL PANEL */}
          <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.2 }} className="p-6 rounded-3xl bg-neutral-900/60 border border-neutral-800">
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-neutral-400 mb-1 ml-1">VOUCHER_ID_OR_URL</label>
                <input type="text" placeholder="Nhập ID Voucher (vd: 33452...)" className="w-full bg-[#121212] border border-neutral-800 rounded-xl px-4 py-3 text-sm font-mono text-white focus:outline-none focus:border-[#ee4d2d] focus:ring-1 focus:ring-[#ee4d2d] transition-all" />
              </div>
              <div>
                <label className="block text-xs font-mono text-neutral-400 mb-1 ml-1">AUTH_COOKIE (SP_TOKEN)</label>
                <input type="password" placeholder="••••••••••••••••••••••••" className="w-full bg-[#121212] border border-neutral-800 rounded-xl px-4 py-3 text-sm font-mono text-white focus:outline-none focus:border-[#ee4d2d] focus:ring-1 focus:ring-[#ee4d2d] transition-all" />
              </div>
              
              <button 
                onClick={toggleArm}
                className={`w-full py-4 rounded-xl font-bold tracking-widest uppercase transition-all duration-300 transform active:scale-95 flex items-center justify-center gap-2
                  ${isArmed 
                    ? 'bg-transparent border-2 border-red-500 text-red-500 hover:bg-red-500/10' 
                    : 'bg-[#ee4d2d] text-white hover:bg-[#ff5d3d] hover:shadow-[0_0_20px_rgba(238,77,45,0.4)]'
                  }
                `}
              >
                {isArmed ? (
                  <>{status === 'FIRING' ? <span className="animate-spin mr-2">⚙️</span> : null} ABORT MISSION</>
                ) : (
                  <><Zap size={18} fill="currentColor"/> KÍCH HOẠT HỎA LỰC</>
                )}
              </button>
            </div>
          </motion.div>
        </div>

        {/* RIGHT COL: TERMINAL LOG */}
        <motion.div 
          initial={{ x: 20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 0.3 }}
          className="md:col-span-5 flex flex-col rounded-3xl bg-[#0d0d0d] border border-neutral-800 overflow-hidden"
        >
          <div className="bg-[#1a1a1a] px-4 py-3 border-b border-neutral-800 flex items-center gap-2">
            <Terminal size={16} className="text-neutral-400" />
            <span className="text-xs font-mono text-neutral-400 tracking-wider">LIVE LOG CONSOLE</span>
          </div>
          
          <div className="p-4 h-[400px] md:h-auto md:flex-1 overflow-y-auto terminal-scrollbar font-mono text-[11px] sm:text-xs space-y-2">
            {logs.map((log) => (
              <motion.div 
                initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} key={log.id}
                className={`flex gap-3 leading-relaxed
                  ${log.type === 'error' ? 'text-red-400' : 
                    log.type === 'success' ? 'text-green-400' : 
                    log.type === 'warning' ? 'text-yellow-400' : 'text-neutral-300'}
                `}
              >
                <span className="text-neutral-600 shrink-0">[{log.time}]</span>
                <span className="break-all">{log.message}</span>
              </motion.div>
            ))}
            <div ref={logEndRef} />
          </div>
        </motion.div>
      </div>

      {/* TOAST NOTIFICATION (Hiển thị khi Success) */}
      {status === 'SUCCESS' && (
        <motion.div 
          initial={{ y: 50, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
          className="fixed bottom-8 right-8 bg-green-500 text-white px-6 py-4 rounded-2xl shadow-[0_10px_40px_rgba(34,197,94,0.4)] flex items-center gap-3 z-50 font-bold"
        >
          <div className="p-2 bg-white/20 rounded-full">
            <Zap size={20} fill="currentColor"/>
          </div>
          <div>
            <p className="text-sm">MISSION ACCOMPLISHED</p>
            <p className="text-xs font-medium text-green-100">Đã lưu mã vào ví Voucher!</p>
          </div>
        </motion.div>
      )}

    </div>
  );
};

export default App;
